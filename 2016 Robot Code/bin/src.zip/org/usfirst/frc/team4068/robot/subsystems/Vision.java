package org.usfirst.frc.team4068.robot.subsystems;

public class Vision {

}
