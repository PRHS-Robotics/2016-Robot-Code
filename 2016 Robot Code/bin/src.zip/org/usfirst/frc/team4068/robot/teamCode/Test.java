package org.usfirst.frc.team4068.robot.teamCode;

import org.usfirst.frc.team4068.robot.Robot.RunCode;

public class Test {
    
    @RunCode(loop=true)
    public static void test(){
        System.out.println("test");
    }
    
}
